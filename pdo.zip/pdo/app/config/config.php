<?php

//inculed files
require_once 'const.php';
require_once 'connection.php';
require_once LIBS_PATH . 'user.lib.php';
require_once ADMIN_LAYOUTS_PATH . 'app.admin.php';
require_once LAYOUTS_PATH . 'app.view.php';




