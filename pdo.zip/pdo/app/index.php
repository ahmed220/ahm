<?php

require_once 'config/config.php';

_header_view("HOME");

?>

CONTENT

<?php
_footer_view();